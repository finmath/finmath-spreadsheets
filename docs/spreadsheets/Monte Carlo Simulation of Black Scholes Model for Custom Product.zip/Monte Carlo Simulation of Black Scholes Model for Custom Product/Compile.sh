#!/bin/sh
#  $JAVA_HOME/bin/javac -source 1.8 -target 1.8 -cp ./lib/finmath-lib.jar classes/*.java
javac -source 1.8 -target 1.8 -cp ./lib/finmath-lib-4.0.5.jar classes/*.java
